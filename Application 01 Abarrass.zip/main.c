/* --------------------------------------------------------------
   Application: 01 - Rev1
   Release Type: Baseline Multitask Skeleton Starter Code 
   Class: Real Time Systems - Su 2025
   AI Use: Commented inline
   Alexander Barrass EEE4775 5346980
---------------------------------------------------------------*/
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

#define LED_PIN GPIO_NUM_4  // Using GPIO2 for the LED

// Task to blink an LED at 2 Hz (500 ms period: 250 ms ON, 250 ms OFF)
void Containment_task(void *pvParameters) {
    bool led_on = false;
    while (1) {
        // TODO: Set LED pin high or low based on led_on flag; right now it's always on... boring; hint in the commented out print statement
        gpio_set_level(LED_PIN, led_on);
        led_on = !led_on;  // toggle state for next time
        printf("LED %s\n", led_on ? "ON" : "OFF");
        vTaskDelay(pdMS_TO_TICKS(250)); //250ms Delay
    }
    vTaskDelete(NULL); //forever loop
}

// Task to print a message every 10000ms (10 seconds)
void Observe_movement_task(void *pvParameters) {
    while (1) {
        // TODO: Print a periodic message based on thematic area. Could be a counter or timestamp.
        printf("PHENOMENON HAS NOT MOVED | CONTAINED\n");       
        vTaskDelay(pdMS_TO_TICKS(10000)); // Delay for 10000 ms
    }
    vTaskDelete(NULL); //forever loop
}

void app_main() {
    // Initialize LED GPIO     
    gpio_reset_pin(LED_PIN);
    gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);
    
    // Instantiate/ Create tasks: 
    // . pointer to task function, 
    // . descriptive name, [has a max length; located in the FREERTOS_CONFIG.H]
    // . stack depth, 
    // . parameters [optional] = NULL 
    // . priority [0 = low], 
    // . pointer referencing this created task [optional] = NULL
    // Learn more here https://www.freertos.org/Documentation/02-Kernel/04-API-references/01-Task-creation/01-xTaskCreate
    xTaskCreate(Containment_task, "Blink Task", 2048, NULL, 1, NULL);
    xTaskCreate(Observe_movement_task, "Print Task", 2048, NULL, 2, NULL);

}
